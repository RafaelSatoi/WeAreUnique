package com.example.weareuniqueprototype

import android.os.Bundle
import android.widget.GridLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.example.weareuniqueprototype.adapter.ServicesAdapter
import com.example.weareuniqueprototype.databinding.ActivityMainBinding
import com.example.weareuniqueprototype.databinding.ActivitySecondPanelBinding
import com.example.weareuniqueprototype.model.Services

class SecondPanel : AppCompatActivity() {

    private lateinit var binding: ActivitySecondPanelBinding
    private lateinit var servicesAdapter: ServicesAdapter
    private val listaServicos: MutableList<Services> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecondPanelBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        supportActionBar?.hide()
        val userName = intent.extras?.getString("userName")

        binding.tituloBemVindo.text = "Bem-vinda(a), $userName"
        val recyclerViewServices = binding.recyclerViewServicos
        recyclerViewServices.layoutManager = GridLayoutManager(this, 2)
        servicesAdapter = ServicesAdapter(this, listaServicos)
        recyclerViewServices.setHasFixedSize(true)
        recyclerViewServices.adapter = servicesAdapter
        getServices()

    }

    private fun getServices(){

        val service1 = Services(R.drawable.busremovebg, "Ônibus")
        listaServicos.add(service1)

        val service2 = Services(R.drawable.subwayremovebg, "Metrô")
        listaServicos.add(service2)

        val service3 = Services(R.drawable.busremovebg, "Ônibus")
        listaServicos.add(service3)

        val service4 = Services(R.drawable.subwayremovebg, "Metrô")
        listaServicos.add(service4)

    }

}