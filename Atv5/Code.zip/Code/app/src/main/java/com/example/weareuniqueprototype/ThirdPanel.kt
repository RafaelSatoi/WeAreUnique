package com.example.weareuniqueprototype

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.weareuniqueprototype.databinding.ActivityThirdPanelBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth

class ThirdPanel : AppCompatActivity() {

    private lateinit var binding:ActivityThirdPanelBinding
    private lateinit var firebaseAuth:FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_third_panel)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        binding = ActivityThirdPanelBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        binding.buttonCreateAccount.setOnClickListener{
            val userName = binding.inputCreateUsuarioNome.text.toString()
            val email = binding.inputCreateEmail.text.toString()
            val senha = binding.inputCreatePassword.text.toString()


            when{
                userName.isEmpty() || email.isEmpty() || senha.isEmpty() -> {
                    mensagem(it, "Complete os dados")
                }
                else -> {
                    firebaseAuth.createUserWithEmailAndPassword(email, senha).addOnCompleteListener{
                        if (it.isSuccessful){
                            val i = Intent(this, MainActivity::class.java)
                            startActivity(i)
                        } else{
                            Toast.makeText(this, it.exception.toString(), Toast.LENGTH_SHORT).show()
                        }

                    }


                }

            }


        }







    }

    private fun mensagem(view: View, mensagem:String){
        val snackbar = Snackbar.make(view, mensagem, Snackbar.LENGTH_SHORT)
        snackbar.setBackgroundTint(Color.parseColor("#f57676"))
        snackbar.setTextColor(Color.parseColor("#FFFFFF"))
        snackbar.show()
    }
}