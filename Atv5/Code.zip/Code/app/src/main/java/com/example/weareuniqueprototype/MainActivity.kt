package com.example.weareuniqueprototype

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.weareuniqueprototype.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    //variaveis
    private lateinit var binding: ActivityMainBinding
    private lateinit var firebaseAuth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        firebaseAuth = FirebaseAuth.getInstance()

        supportActionBar?.hide()

        //botão de criar conta
        binding.createAccount.setOnClickListener(){
            createAccount()
        }


        //botão de login
        binding.loginBtn.setOnClickListener(){
            //receber userName, password e botão
            val email = binding.emailInput.text.toString()
            val password = binding.passwordInput.text.toString()

            Log.d("MainActivity", "teste")

            //deixar em branco
            when{
                email.isEmpty() && password.isEmpty() -> {
                    mensagem(it, "Preencha os campos")
                }password.isEmpty() -> {
                    mensagem(it, "Preencha a senha")
                }email.isEmpty() -> {
                    mensagem(it, "Coloque seu nome")
                }
                else -> {
                    login(email, password)
                }
            }

        }

    }

    private fun login(email:String, password:String){

        firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener {
            if (it.isSuccessful){
                val intent = Intent(this, MainActivityTest::class.java)
                startActivity(intent)
            } else{
                Toast.makeText(this, it.exception.toString(), Toast.LENGTH_SHORT).show()
            }
        }



    }

    private fun createAccount(){
        val intent = Intent(this, ThirdPanel::class.java)
        startActivity(intent)

    }

    private fun mensagem(view: View, mensagem:String){
        val snackbar = Snackbar.make(view, mensagem, Snackbar.LENGTH_SHORT)
        snackbar.setBackgroundTint(Color.parseColor("#f57676"))
        snackbar.setTextColor(Color.parseColor("#FFFFFF"))
        snackbar.show()
    }



}