package com.example.weareuniqueprototype.model

data class Services (
    val img: Int? = null,
    val userName: String? = null

)






