package com.example.weareuniqueprototype

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.weareuniqueprototype.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    //variaveis
    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        supportActionBar?.hide()

        //botão de criar conta
        binding.createAccount.setOnClickListener(){
            createAccount()
        }


        //botão de login
        binding.loginBtn.setOnClickListener(){
            //receber userName, password e botão
            val userName = binding.usernameInput.text.toString()
            val password = binding.passwordInput.text.toString()


            //deixar em branco
            when{
                userName.isEmpty() && password.isEmpty() -> {
                    mensagem(it, "Preencha os campos")
                }password.isEmpty() -> {
                    mensagem(it, "Preencha a senha")
                }userName.isEmpty() -> {
                    mensagem(it, "Coloque seu nome")
                }userName != "admin" || password != "123" -> {
                    mensagem(it, "Os dados estão incorretos!")
                }
                else -> {
                    login(userName)
                }
            }

        }

    }

    private fun login(userName: String){

        val intent = Intent(this, MainActivityTest::class.java)
        intent.putExtra("userName", userName)
        startActivity(intent)

    }

    private fun createAccount(){

        val intent = Intent(this, ThirdPanel::class.java)
        startActivity(intent)

    }

    private fun mensagem(view: View, mensagem:String){
        val snackbar = Snackbar.make(view, mensagem, Snackbar.LENGTH_SHORT)
        snackbar.setBackgroundTint(Color.parseColor("#f57676"))
        snackbar.setTextColor(Color.parseColor("#FFFFFF"))
        snackbar.show()
    }



}