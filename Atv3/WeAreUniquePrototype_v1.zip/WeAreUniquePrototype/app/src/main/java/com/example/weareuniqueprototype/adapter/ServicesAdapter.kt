package com.example.weareuniqueprototype.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.weareuniqueprototype.databinding.ServicesItemBinding
import com.example.weareuniqueprototype.model.Services

class ServicesAdapter(
    private val context: Context, private val listaServices: MutableList<Services>):
    RecyclerView.Adapter<ServicesAdapter.ServicesViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServicesViewHolder {
        val itemLista = ServicesItemBinding.inflate(LayoutInflater.from(context), parent, false)
        return ServicesViewHolder(itemLista)
    }

    override fun getItemCount() = listaServices.size

    override fun onBindViewHolder(holder: ServicesViewHolder, position: Int) {
        holder.imgServices.setImageResource(listaServices[position].img!!)
        holder.txtServices.text = listaServices[position].userName
    }

    inner class ServicesViewHolder(binding: ServicesItemBinding): RecyclerView.ViewHolder(binding.root){
        val imgServices = binding.imgServices
        val txtServices = binding.txtServicos
    }


}